﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using SearchEnging.Adaptors;

namespace SearchEnging.retrieval.boolean
{
    public class Retriever
    {
        public List<DocumentWrapper> getDocumentsContainingWords(List<String> words)
        {
            List<DocumentWrapper> list = new List<DocumentWrapper>();
            if (words.Count == 0)
                return list;

            IndexManager manager = IndexManager.getInstance();
            var containingFirstWord = manager.getDocumentsContainingWord(words[0]);
            foreach (var doc in containingFirstWord)
                list.Add(doc);

            for (int i = 1; i < words.Count; i++)
            {
                String word = words[i];
                var docsContainingThisWord = manager.getDocumentsContainingWord(word);
                list = list.Intersect(docsContainingThisWord).ToList();
            }

            return list;
        }

        public List<DocumentWrapper> getDocumentsForBooleanQuery(BooleanQuery query)
        {
            if (query.getTermsCount() == 0)
                return new List<DocumentWrapper>();

            query.setCurrentTerm(0);

            List<DocumentWrapper> docs = new List<DocumentWrapper>();

            IndexManager manager = IndexManager.getInstance();

            while (true)
            {
                List<String> term = query.getNextTerm();
                if (term == null)
                    break;

                var docsSatisfyingThisTerm = this.getDocumentsContainingWords(term);

                docs = docs.Union(docsSatisfyingThisTerm).ToList();
            }

            return docs;
        }
    }
}