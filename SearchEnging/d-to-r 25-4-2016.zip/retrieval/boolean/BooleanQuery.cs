﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace SearchEnging.retrieval
{
    public class BooleanQuery
    {
        private List<List<String>> terms;
        private int currentTerm = 0;

        public BooleanQuery()
        {
            this.terms = new List<List<string>>();
        }

        public void clearAll()
        {
            this.terms.Clear();
        }

        public void addTerm(List<String> termWords)
        {
            terms.Add(termWords);
        }

        public List<String> getNextTerm()
        {
            if (currentTerm < terms.Count)
                return terms[currentTerm++];
            else return null;
        }

        public void setCurrentTerm(int index)
        {
            if (index < terms.Count)
                this.currentTerm = index;
            else throw new Exception("Invalid index from current term");
        }

        public int getTermsCount()
        {
            return this.terms.Count();
        }
    }
}